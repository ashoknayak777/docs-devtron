# GitOps

## Introduction

In Devtron, you can use either Helm, GitOps (Argo CD), or GitOps (Flux CD) as your deployment method while deploying your application. When you choose Helm as your preferred deployment method, you are deploying your application directly into the Kubernetes cluster without version tracking of any kind. 

However, if you choose GitOps - a branch of DevOps that focuses on using Git repositories as a single source of truth - Devtron stores Kubernetes configuration files (e.g., Kubernetes manifests or YAML configs) and the desired state of your applications in Git repositories to track each and every deployment.

![Figure 1: GitOps Approach](https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/global-configurations/gitops/gitops-approach.jpg)

Whenever tools like Argo CD or Flux CD recognize changes in the Git repository, they apply those changes to the Kubernetes cluster automatically. Similarly, if they notice any change in the cluster, they will revert back the cluster to the Git-defined state.

---

## Steps to Configure GitOps

:::caution Who Can Perform This Action?
Users need to have [Super-Admin](user-access.md#assign-super-admin-permissions) permission to configure GitOps.

:::

1. Go to **Application Management** → **Configurations** → **GitOps**

   ![Figure 2: Global Configuration - GitOps](https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/global-configurations/gitops/gitops-v1.jpg)

2. Select any one of the [supported Git providers](#supported-git-providers) to configure GitOps. 

   ![Figure 3: Selecting a Provider](https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/global-configurations/gitops/select-provider-v1.jpg)

:::caution 
The Git provider you select for configuring GitOps might impact the following sections:

   * [Deployment Template](../creating-application/base-config/deployment-template.md)

   * [Charts](../deploy-chart/README.md)

:::

3. Fill all the mandatory fields. Refer [supported Git providers](#supported-git-providers) to know more about the respective fields.

   ![Figure 4: Entering Git Credentials](https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/global-configurations/gitops/git-fields.jpg)

4. In the **Directory Management in Git** section, you get the following options:

   * **Auto-create git repository for each application**:
   
      This option lets Devtron automatically create a GitOps repository within your organization. The repository name will match your application name, and it cannot be changed. Since Devtron needs admin access to create the repository, ensure the Git credentials you provided in Step 3 have administrator rights.

   * **Ask git repository for each application**: 
   
      Select this option if you wish to use your own GitOps repo. This is ideal if there are any confidentiality/security concerns that prevent you from giving us admin access. Therefore, the onus is on you to create a GitOps repo with your Git provider, and then [add it to the specific application](../creating-application/gitops-config.md) on Devtron. Make sure the Git credentials you provided in Step 3 have at least read/write access. Choosing this option will unlock a [GitOps Configuration](../creating-application/gitops-config.md) page under the [App Configuration](../creating-application/README.md) tab.

   ![Figure 5: Need for User-defined Git Repo](https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/global-configurations/gitops/user-defined-git.jpg)

5. Click **Save**/**Update**. A green tick will appear on the active Git provider.

### Feature Flag

Alternatively, you may use the feature flag **FEATURE_USER_DEFINED_GITOPS_REPO_ENABLE** to enable or disable custom GitOps repo.

:::info 
**For disabling** - `FEATURE_USER_DEFINED_GITOPS_REPO_ENABLE: "false"` <br/>
**For enabling** - `FEATURE_USER_DEFINED_GITOPS_REPO_ENABLE: "true"`
:::

#### How to Use Feature Flag

![Using Feature Flag](https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/global-configurations/gitops/dashboard-cm.gif)

1. Go to [Devtron's Resource Browser](../resource-browser/README.md).

2. Select the cluster where Devtron is running, i.e., `default_cluster`.

3. Go to the **Config & Storage** dropdown on the left.

4. Click **ConfigMap**.

5. Use the namespace filter (located on the right-hand side) to select `devtroncd` namespace. Therefore, it will show only the ConfigMaps related to Devtron, and filter out the rest.

6. Find the ConfigMap meant for the dashboard of your Devtron instance, i.e., `dashboard-cm` (with an optional suffix).

7. Click **Edit Live Manifest**.

8. Add the feature flag (with the intended boolean value) within the `data` dictionary 

9. Click **Apply Changes**.

---

## Supported Git Providers

Below are the Git providers supported in Devtron for storing configuration files. 

* [GitHub](#github)
* [GitLab](#gitlab)
* [AWS Code Commit](#aws-code-commit-)
* [Azure](#azure)
* [Bitbucket](#bitbucket)
* [Other GitOps](#other-gitops-)

### GitHub

:::info Prerequisite
1. A GitHub account
2. A GitHub organization. If you don't have one, refer [Creating Organization in GitHub](#creating-organization-in-github).
:::

Fill the following mandatory fields:

| Field | Description |
| --- | --- |
| **Git Host** | Shows the URL of GitHub, e.g., https://github.com/ |
| **GitHub Organisation Name** | Enter the GitHub organization name. <br/>If you do not have one, refer [How to create organization in GitHub](#creating-organization-in-github). |
| **GitHub Username** | Provide the username of your GitHub account |
| **Personal Access Token** | Provide your personal access token (PAT). It is used as an alternate password to authenticate your GitHub account. <br/>If you do not have one, create a GitHub PAT [here](https://docs.github.com/en/github/authenticating-to-github/creating-a-personal-access-token). <br/><br/> **Access Required**: <br/> `repo` - Full control of private repositories (able to access commit status, deployment status, and public repositories). <br/> `admin:org` - Full control of organizations and teams (Read and Write access). May not be required if you are using user-defined git repo. <br/> `delete_repo` - Grants delete repo access on private repositories. |

### GitLab

:::info Prerequisite
1. A GitLab account

2. A GitLab group. If you don't have one, refer [Creating Group in GitLab](#creating-group-in-gitlab).

:::

Fill the following mandatory fields:

| Field | Description |
| --- | --- |
| **Git Host** | Shows the URL of GitLab, e.g., https://gitlab.com/ |
| **GitLab Group ID** | Enter the GitLab group ID. <br/>If you do not have one, refer [GitLab Group ID](#creating-group-in-gitlab).|
| **GitLab Username** | Provide the username of your GitLab account |
| **Personal Access Token** | Provide your personal access token (PAT). It is used as an alternate password to authenticate your GitLab account. <br/>If you do not have one, create a GitLab PAT [here](https://docs.gitlab.com/ee/user/profile/personal_access_tokens.html). <br/><br/> **Access Required**: <br/> `api` - Grants complete read/write access to the scoped project API. <br/> `write_repository` - Allows read/write access (pull, push) to the repository.|

### AWS Code Commit <a href="https://devtron.ai/pricing"><img src="https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/elements/EnterpriseTag.svg" className="enterprise-badge-img" /></a>

:::info Prerequisites
1. Existing user of AWS CodeCommit ([as AWS stopped adding new customers to it](https://aws.amazon.com/blogs/devops/how-to-migrate-your-aws-codecommit-repository-to-another-git-provider/))

2. An AWS IAM user with `AWSCodeCommitPowerUser` permission. Refer to [Create and Configure an IAM User with AWSCodeCommitPowerUser Permission](https://docs.aws.amazon.com/codecommit/latest/userguide/setting-up-gc.html#setting-up-gc-account) for more information.

3. Obtain SSH Key ID and SSH Private Key. Refer to [Generating SSH Private Key in AWS Code Commit](https://docs.aws.amazon.com/codecommit/latest/userguide/setting-up-ssh-unixes.html) for more information.

:::

![Figure 6: AWS Code Commit](https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/global-configurations/gitops/aws-code-commit.jpg)

Fill the following mandatory fields:

| Field | Description |
| --- | --- |
| **SSH Host** | Enter the AWS Code Commit SSH host URL (e.g., `ssh://git-codecommit.ap-south-1.amazonaws.com`)|
| **Enter username** | Enter the username (SSH Key ID), e.g., `APKDKDIERJS9EXAMPLE`. | 
| **SSH Private Key** | Enter the SSH private key. | 

Click **Save**. 

### Azure

:::info Prerequisites
1. An organization on Azure DevOps. If you don't have one, refer [this link](https://learn.microsoft.com/en-us/azure/devops/organizations/accounts/create-organization?view=azure-devops#create-an-organization).

2. A project in your Azure DevOps organization. Refer [Creating Project in Azure](#creating-project-in-azure-devops).

:::

Fill the following mandatory fields:

| Field | Description |
| --- | --- |
| **Azure DevOps Organisation Url*** | Enter the Org URL of Azure DevOps. Format should be `https://dev.azure.com/<org-name>`, where `<org-name>` represents the organization name, e.g., [https://dev.azure.com/devtron-test](https://dev.azure.com/devtron-test)|
| **Azure DevOps Project Name** | Enter the Azure DevOps project name. <br/>If you do not have one, refer [Azure DevOps Project Name](#creating-project-in-azure-devops).|
| **Azure DevOps Username*** | Provide the username of your Azure DevOps account |
| **Azure DevOps Access Token*** | Provide your Azure DevOps access token. It is used as an alternate password to authenticate your Azure DevOps account. <br/>If you do not have one, create a Azure DevOps access token [here](https://docs.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate?view=azure-devops&tabs=preview-page). <br/><br/> **Access Required**: <br/> `code` - Grants the ability to read source code and metadata about commits, change sets, branches, and other version control artifacts. [More information on scopes in Azure DevOps](https://docs.microsoft.com/en-us/azure/devops/integrate/get-started/authentication/oauth?view=azure-devops#scopes). |

### Bitbucket

Here, you get 2 options:

* [Bitbucket Cloud](#bitbucket-cloud) - Select this if you wish to store GitOps configuration in a web-based Git repository hosting service offered by Bitbucket.

* [Bitbucket Data Center](#bitbucket-data-center) - Select this if you wish to store GitOps configuration in a git repository hosted on a self-managed Bitbucket Data Center (on-prem).

#### Bitbucket Cloud

:::info Prerequisite
1. A Bitbucket account

2. A workspace in your Bitbucket account. Refer [Creating Workspace in Bitbucket](#creating-workspace-in-bitbucket).

:::

![Figure 7: Entering Details of Bitbucket Cloud](https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/global-configurations/gitops/bitbucket-cloud-v1.jpg)

Fill the following mandatory fields:

| Field | Description |
| --- | --- |
| **Bitbucket Host** | Shows the URL of Bitbucket Cloud, e.g., https://bitbucket.org/ |
| **Bitbucket Workspace ID** | Enter the Bitbucket workspace ID. <br/>If you do not have one, refer [Bitbucket Workspace ID](#creating-workspace-in-bitbucket)|
| **Bitbucket Project Key** | Enter the Bitbucket project key. <br/>If you do not have one, refer [Bitbucket Project Key](https://support.atlassian.com/bitbucket-cloud/docs/group-repositories-into-projects/). <br/>Note: If the project is not provided, the repository is automatically assigned to the oldest project in the workspace. |
| **Bitbucket Username*** | Provide the username of your Bitbucket account |
| **Personal Access Token** | Provide your personal access token (PAT). It is used as an alternate password to authenticate your Bitbucket Cloud account. <br/>If you do not have one, create a Bitbucket Cloud PAT [here](https://support.atlassian.com/bitbucket-cloud/docs/app-passwords/). <br/><br/> **Access Required**: <br/> `repo` - Full control of repositories (Read, Write, Admin, Delete) access. |

#### Bitbucket Data Center

:::info Prerequisite
A Bitbucket Data Center account

:::

![Figure 8: Entering Details of Bitbucket Data Center](https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/global-configurations/gitops/bitbucket-server-v1.jpg)

Fill the following mandatory fields:

| Field | Description |
| --- | --- |
| **Bitbucket Host** | Enter the URL address of your Bitbucket Data Center, e.g., https://bitbucket.mycompany.com |
| **Bitbucket Project Key** | Enter the Bitbucket project key. Refer [Bitbucket Project Key](https://confluence.atlassian.com/bitbucketserver/creating-projects-776639848.html). |
| **Bitbucket Username*** | Provide the username of your Bitbucket Data Center account |
| **Password** | Provide the password to authenticate your Bitbucket Data Center account |

### Other GitOps <a href="https://devtron.ai/pricing"><img src="https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/elements/EnterpriseTag.svg" className="enterprise-badge-img" /></a>

![Figure 9: Other GitOps](https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/global-configurations/gitops/other-gitops.jpg)

If you prefer to use the GitOps approach using a different platform other than the available ones, refer to the following table and fill in the mandatory fields:

| Field | Description |
| --- | --- |
| **SSH Host** | Enter the SSH host URL (e.g., `ssh://git@<host>:<path>/<repo-name>.git`). | 
| **Enter username** | Enter the username (e.g., `git`). For other GitOps, the username will differ depending on the provider (e.g., personal access token or access key ID). | 
| **SSH Private Key** | Enter the SSH private key (e.g., `M7YtY8cdJKhZ7nYXxgXeqNffv`) here against the public key added to your GitOps provider. | 

Click **Save**. 

---

## Miscellaneous

### Creating Organization in GitHub

:::caution 
We do **NOT** recommend using GitHub organization that contains your source code.
:::

<div class="video-wrapper"><iframe width="560" height="315" src="https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/global-configurations/gitops/github/github-gitops-latest.mp4" title="GitHub" frameborder="0" allowfullscreen></iframe></div>

1. Create a new account on GitHub (if you do not have one).
2. On the upper-right corner of your GitHub page, click your profile photo, then click **Settings**.
3. On the `Access` section, click  **Organizations**.
4. On the `Organizations` section, click **New organization**.
5. Pick a [plan](https://docs.github.com/en/get-started/learning-about-github/githubs-products) for your organization. You have the option to select `create free organization` also.
6. On the `Set up your organization` page, 
   * Enter the `organization account name`, `contact email`.
   * Select the option your organization belongs to.
   * Verify your account and click **Next**.
   * Your `GitHub organization name` will be created. 

7. Go to your profile and click **Your organizations** to view all the organizations you created.

:::info Additional References
For more information about the plans available for your team, see [GitHub's products](https://docs.github.com/en/get-started/learning-about-github/githubs-products). You can also refer [GitHub organization](https://docs.github.com/en/github/setting-up-and-managing-organizations-and-teams/about-organizations) official doc page for more detail.
:::


### Creating Group in GitLab

<div class="video-wrapper"><iframe width="560" height="315" src="https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/global-configurations/gitops/gitlab/gitops-gitlab-latest1.mp4" title="GitHub" frameborder="0" allowfullscreen></iframe></div>


1. Create a new account on GitLab (if you do not have one).
2. You can create a group by going to the 'Groups' tab on the GitLab dashboard and click `New group`.
3. Select `Create group`.
4. Enter the group name (required) and select the optional descriptions if required, and click **Create group**.
5. Your group will be created and your group name will be assigned with a new `Group ID` (e.g. 61512475).


### Creating Project in Azure DevOps

![Figure 10a: New Project Button in Azure DevOps](https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/global-configurations/gitops/azure+devops/azure-new-project-v2.jpg)

![Figure 10b: Create New Project](https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/global-configurations/gitops/azure+devops/azure-create-new-project-v2.jpg)

1. Go to Azure DevOps and navigate to Projects.
2. Select your organization and click `New project`. 
3. On the `Create new project` page, 
   * Enter the `project name` and description of the project.
   * Select the visibility option (private or public), initial source control type, and work item process.
   * Click **Create**.
   * Azure DevOps displays the project welcome page with the `project name`.

:::info Additional References
You can also refer [Azure DevOps - Project Creation](https://docs.microsoft.com/en-us/azure/devops/organizations/projects/create-project?view=azure-devops&tabs=preview-page) official page for more details.
:::


### Creating Workspace in Bitbucket

<div class="video-wrapper"><iframe width="560" height="315" src="https://devtron-public-asset.s3.us-east-2.amazonaws.com/images/global-configurations/gitops/bitbucket/bitbucket-latest-gitops.mp4" title="GitHub" frameborder="0" allowfullscreen></iframe></div>

1. Create a new individual account on Bitbucket (if you do not have one).
2. Select your profile and settings avatar on the upper-right corner of the top navigation bar.
3. Select `All workspaces` from the dropdown menu.
4. Select the `Create workspace` on the upper-right corner of the `Workspaces` page.
5. On the `Create a Workspace` page:
  * Enter a `Workspace name`. 
  * Enter a `Workspace ID`. Your ID cannot have any spaces or special characters, but numbers and capital letters are fine. This ID becomes part of the URL for the workspace and anywhere else where there is a label that identifies the team (APIs, permission groups, OAuth, etc.).
  * Click **Create**.
6. Your `Workspace name` and `Workspace ID` will be created.

:::info Additional References
You can also refer [official Bitbucket Workspace page](https://support.atlassian.com/bitbucket-cloud/docs/what-is-a-workspace/) for more details.
:::