import Tabs from '@theme/Tabs';
import TabItem from '@theme/TabItem';

# Upgrade Hyperion to Devtron Full mode

To install Helm3, please check [Installing Helm3](https://helm.sh/docs/intro/install/)

<Tabs>
<TabItem label="Upgrade with default configurations" value="Upgrade with default configurations">
This installation will use Minio for storing build logs and cache.

```bash
helm upgrade devtron devtron/devtron-operator --namespace devtroncd --set installer.mode=full
```
</TabItem>

<TabItem label="Upgrade with AWS S3" value="Upgrade with AWS S3">
This installation will use AWS s3 buckets for storing build logs and cache

```bash
helm upgrade devtron devtron/devtron-operator --create-namespace --namespace devtroncd \
--set installer.mode=full \
--set configs.BLOB_STORAGE_PROVIDER=S3 \
--set configs.DEFAULT_CACHE_BUCKET=demo-s3-bucket \
--set configs.DEFAULT_CACHE_BUCKET_REGION=us-east-1 \
--set configs.DEFAULT_BUILD_LOGS_BUCKET=demo-s3-bucket \
--set configs.DEFAULT_CD_LOGS_BUCKET_REGION=us-east-1
```
</TabItem>

<TabItem label="Upgrade with Azure Blob Storage" value="Upgrade with Azure Blob Storage">
This installation will use Azure Blob Storage for storing build logs and cache

```bash
helm upgrade devtron devtron/devtron-operator --create-namespace --namespace devtroncd \
--set installer.mode=full \
--set secrets.AZURE_ACCOUNT_KEY=xxxxxxxxxx \
--set configs.BLOB_STORAGE_PROVIDER=AZURE \
--set configs.AZURE_ACCOUNT_NAME=test-account \
--set configs.AZURE_BLOB_CONTAINER_CI_LOG=ci-log-container \
--set configs.AZURE_BLOB_CONTAINER_CI_CACHE=ci-cache-container
```
</TabItem>
</Tabs>


If you are planning to use Devtron for `production deployments`, please refer to our recommended overrides for [Devtron Installation](../../setup/install/override-default-devtron-installation-configs.md).

## Installation status

Run following command

```bash
kubectl -n devtroncd get installers installer-devtron -o jsonpath='{.status.sync.status}'
```

The install commands initiates Devtron-operator which spins up all the Devtron micro-services one by one in about 20 mins. You can use the above command to check the status of the installation if the installation is still in progress, it will print `Downloaded`. When the installation is complete, it prints `Applied`.

## Access Devtron dashboard

If you did not provide a **BASE\_URL** during install or have used the default installation, Devtron creates a loadbalancer for you on its own. Use the following command to get the dashboard url.

```text
kubectl get svc -n devtroncd devtron-service -o jsonpath='{.status.loadBalancer.ingress}'
```

You will get result something like below

```text
[test2@server ~]$ kubectl get svc -n devtroncd devtron-service -o jsonpath='{.status.loadBalancer.ingress}'
[map[hostname:aaff16e9760594a92afa0140dbfd99f7-305259315.us-east-1.elb.amazonaws.com]]
```

The hostname mentioned here \( aaff16e9760594a92afa0140dbfd99f7-305259315.us-east-1.elb.amazonaws.com \) is the Loadbalancer URL where you can access the Devtron dashboard.

**PS:** You can also do a CNAME entry corresponding to your domain/subdomain to point to this Loadbalancer URL to access it at a custom domain.

| Host | Type | Points to |
| ---: | :--- | :--- |
| devtron.yourdomain.com | CNAME | aaff16e9760594a92afa0140dbfd99f7-305259315.us-east-1.elb.amazonaws.com |

### Devtron Admin credentials
If you are upgrading from Hyperion to Devtron full mode, the admin password does NOT change.
For admin login use username:`admin` and for password run the following command.

```bash
kubectl -n devtroncd get secret devtron-secret -o jsonpath='{.data.ACD_PASSWORD}' | base64 -d
```

### Cleaning Devtron Installer Helm3

Please make sure that you do not have anything inside namespaces devtroncd, devtron-cd devtron-ci and devtron-demo as the below steps will clean everything inside these namespaces
```
helm uninstall devtron --namespace devtroncd
kubectl delete -n devtroncd -f https://raw.githubusercontent.com/devtron-labs/charts/main/charts/devtron/crds/crd-devtron.yaml
kubectl delete -n argo -f https://raw.githubusercontent.com/devtron-labs/devtron/main/manifests/yamls/workflow.yaml
kubectl delete ns devtroncd devtron-cd devtron-ci devtron-demo
```
